var siteinfo = {
    name: "本源码由QQ614096466 猫咪科技独家提供提取",
    uniacid: "2",
    acid: "2",
    multiid: "0",
    version: "8.3.1",
  siteroot: "https://api4.minidope.com/app/index.php",
    design_method: "3"
};

module.exports = siteinfo;