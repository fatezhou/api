<?php defined('IN_IA') or exit('Access Denied');?><style>
/*.bootstrap-switch .bootstrap-switch-handle-on.bootstrap-switch-primary, .bootstrap-switch .bootstrap-switch-handle-off.bootstrap-switch-primary {color: #fff;background: #a0053b;}*/
/*.btn-primary {color: #fcfafa;background-color: #3b3063;border-color: #ffffff;}*/
/*.list-group .list-group-item.active {background-color: #3b3063;border-color: #f3f0f2;}*/
/*.nav-tabs > li.active > a, .nav-tabs > li.active > a:hover, .nav-tabs > li.active > a:focus {color: #FFF;background-color: #c83716;border-color: #c83716;}*/
/*.nav.nav-tabs {margin-bottom: 10px;border-color: #c83716;}*/
/*.btn-default {color: #f4eeee;background-color: #169786;border-color: #f2f7f7;}*/
/*.panel-info > .panel-heading {color: #fbfdfe;background-color: #179786;border-color: #49a2b4;}*/
/*.pagination > .active > a, .pagination > .active > span, .pagination > .active > a:hover, .pagination > .active > span:hover, .pagination > .active > a:focus, .pagination > .active > span:focus {z-index: 2;color: #fff;cursor: default;background-color: #3b3063;border-color: #3b3063;}*/
/*.daterangepicker .ranges li.active, .daterangepicker .ranges li:hover {background: #3b3063;border: 1px solid #3b3063;color: #fff;}*/
/*.daterangepicker td.active, .daterangepicker td.active:hover {background-color: #d9534f;border-color: #ffffff;color: #fff;}*/
/*.input-group-addon {padding: 6px 12px;font-size: 14px;font-weight: 400;line-height: 1;color: #555;text-align: center;background-color: #e2a385;border: 1px solid #ccc;border-radius: 4px;}*/
/*.form-control-excel {height: 34px;padding: 6px 12px;font-size: 14px;line-height: 1.42857143;color: #555;background-color: #fff;background-image: none;border: 1px solid #ccc;border-radius: 4px;-webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.075);box-shadow: inset 0 1px 1px rgba(0,0,0,.075);-webkit-transition: border-color ease-in-out .15s,-webkit-box-shadow ease-in-out .15s;-o-transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;}*/
/*.ibox {clear: both;margin-bottom: 25px;margin-top: 0;padding: 0;}*/
/*.ibox-title {-moz-border-bottom-colors: none;-moz-border-left-colors: none;-moz-border-right-colors: none;-moz-border-top-colors: none;background-color: #ffffff;border-color: #e7eaec;-webkit-border-image: none;-o-border-image: none;border-image: none;border-width: 4px 0px 0;color: inherit;margin-bottom: 0;padding: 14px 15px 7px;min-height: 48px;}*/
/*.ibox-content {clear: both;background-color: #ffffff;color: inherit;padding: 15px 20px 20px 20px;border-color: #e7eaec;-webkit-border-image: none;-o-border-image: none;border-image: none;border-style: solid solid none;border-width: 1px 0px;}	*/
/*.text-info {color: #23c6c8;}*/
/*.font-bold {font-weight: 600;}*/
/*.stat-percent {float: right;}*/
/* 门店图片 */
.panel-slide{position: relative;}
.panel-slide .btnClose{position: absolute; top:-10px; right:-10px; width:30px; height: 30px; border-radius: 30px;background: #eee; font-size: 16px; cursor: pointer; color:#FFF; text-align: center; line-height: 30px}
.panel-slide .btnClose:hover{background: red}
.panel-slide .panel-body div{margin-top: 10px}
</style>
