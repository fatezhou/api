<?php defined('IN_IA') or exit('Access Denied');?><?php (!empty($this) && $this instanceof WeModuleSite || 1) ? (include $this->template('public/header', TEMPLATE_INCLUDEPATH)) : (include template('public/header', TEMPLATE_INCLUDEPATH));?>
<?php (!empty($this) && $this instanceof WeModuleSite || 1) ? (include $this->template('public/comhead', TEMPLATE_INCLUDEPATH)) : (include template('public/comhead', TEMPLATE_INCLUDEPATH));?>
<link rel="stylesheet" type="text/css" href="../addons/zh_dianc/template/public/ygcsslist.css">
<style type="text/css">
.ygrow{font-size: 12px;color: #44ABF7;}
    .yg5_key>div{float: left;line-height: 34px;}
    .store_td1{height: 45px;}
    .store_list_img{width: 40px;height: 40px;}
    .yg5_tabel{border-color: #e5e5e5;outline: 1px solid #e5e5e5;text-align: center;}
    .yg5_tr2>td{padding: 10px;border: 1px solid #e5e5e5;}
    .yg5_tr1>td{

        border: 1px solid #e5e5e5;
        background-color: #FAFAFA;
        font-weight: bold;

    }
    .yg5_btn{background-color: #EEEEEE;color: #333;border: 1px solid #E4E4E4;border-radius: 6px;width: 100px;height: 34px;}
    .check_img{width: 45px;height: 45px;}
    .main{font-size: 12px;}
    /*#frame-13{display: block;visibility: visible;}*/
</style>
<ul class="nav nav-tabs">
    <span class="ygxian"></span>
    <div class="ygdangq">当前位置:</div>    
    <li class="active"><a href="">充值记录</a></li>
</ul>
<br>
<div class="row ygrow">
    <form action="" method="get" class="col-md-3">
       <input type="hidden" name="c" value="site" />
       <input type="hidden" name="a" value="entry" />
       <input type="hidden" name="m" value="zh_jdgjb" />
       <input type="hidden" name="do" value="czjl" />
       <div class="input-group">
        <input type="text" name="keywords" class="form-control" value="<?php  echo $_GPC['keywords'];?>" placeholder="请输入昵称" style="font-size: 12px;">
        <span class="input-group-btn">
            <input type="submit" class="btn btn-default" name="submit" value="查找"/>
        </span>
    </div>
    <input type="hidden" name="token" value="<?php  echo $_W['token'];?>"/>
</form>
<!--   <div class="col-md-4 userremark">人工充值：双击可修改余额，输入值与原有值进行累加充值。</div> -->
</div>
<div class="main">

    <div class="panel panel-default">

        <div class="panel-heading">

          充值记录

        </div>

        <div class="panel-body" style="padding: 0px 15px;">

          <div class="row">

            <table class="yg5_tabel col-md-12">

              <tr class="yg5_tr1">

                <td class="store_td1">用户头像</td>
                <td>用户名称</td>
                <td>充值金额</td>
                 <td>赠送金额</td>
                <td>充值方式</td>  
                <td>充值时间</td>
                </tr>
                <?php  if(is_array($list)) { foreach($list as $key => $item) { ?>
                <tr class="yg5_tr2">
                        <td ><img class="store_list_img" src="<?php  echo $item['img'];?>"/></td>
                         <td ><?php  echo $item['name'];?></td>
                        <td><?php  echo $item['cz_money'];?></td>
                        <td><?php  echo $item['zs_money'];?></td>
                        <td><?php  echo $item['note'];?></td>
                        <td><?php  echo date('Y-m-d H:i:s',$item['time'])?></td>
                  </td>

                </tr>

                <?php  } } ?>
                <?php  if(empty($list)) { ?>
                <tr class="yg5_tr2">
                  <td colspan="5">
                    暂无充值记录
                  </td>
                </tr> 
                <?php  } ?>        



              </table>

            </div>

        </div>

    </div>

</div>

<div class="text-right we7-margin-top">
<?php  echo $pager;?>
</div>

<script type="text/javascript">
    $(function(){
        // $("#frame-13").addClass("in");
        $("#frame-3").show();
        $("#yframe-3").addClass("wyactive");
    })
</script>