<?php defined('IN_IA') or exit('Access Denied');?><?php (!empty($this) && $this instanceof WeModuleSite || 1) ? (include $this->template('public/header', TEMPLATE_INCLUDEPATH)) : (include template('public/header', TEMPLATE_INCLUDEPATH));?>

<?php (!empty($this) && $this instanceof WeModuleSite || 1) ? (include $this->template('public/comhead', TEMPLATE_INCLUDEPATH)) : (include template('public/comhead', TEMPLATE_INCLUDEPATH));?>
<link rel="stylesheet" type="text/css" href="../addons/zh_jdgjb/template/public/ygcsslist.css">
<style type="text/css">
    .ygrow{font-size: 12px;color: #44ABF7;}
    .userremark{line-height: 35px;}
    .userinfolist{font-size: 14px;line-height: 30px;}
    .userilfirst{font-weight: bold;}
    .userilsecond{margin-left: 30px;}
    .userinfolist2>li>span{cursor: pointer;}
    .usertuinfo{width: 100%;height: 100%;position: absolute;left: 0px;top: 0px;z-index: 10;border:1px solid #eee;display: none;background-color: rgba(0,0,0,0.5);text-align: center;}
    .usertuinfo>img{width: 400px;height: 233px;margin-top: 15px;}
    .usertuinfo>div{position: absolute;right: 20%;top: 5px;z-index: 11;}
</style>
<ul class="nav nav-tabs">    
    <span class="ygxian"></span>
    <div class="ygdangq">当前位置:</div>
    <li class="active"><a href="javascript:void(0);">会员列表</a></li>
</ul>

<div class="row ygrow">
    <form action="" method="get" class="col-md-3">
       <input type="hidden" name="c" value="site" />
       <input type="hidden" name="a" value="entry" />
       <input type="hidden" name="m" value="zh_jdgjb" />
       <input type="hidden" name="do" value="user2" />
       <div class="input-group">
        <input type="text" name="keywords" class="form-control" value="<?php  echo $_GPC['keywords'];?>" placeholder="请输入昵称" style="font-size: 12px;">
        <span class="input-group-btn">
            <input type="submit" class="btn btn-default" name="submit" value="查找"/>
        </span>
    </div>
    <input type="hidden" name="token" value="<?php  echo $_W['token'];?>"/>
</form>
<!--   <div class="col-md-4 userremark">人工充值：双击可修改余额，输入值与原有值进行累加充值。</div> -->
</div>
<div class="main">
    <div class="panel panel-default">

        <div class="panel-heading">用户列表</div>
        <div class="panel-body" style="padding: 0px 15px;">

            <div class="row">

                <table class="yg5_tabel col-md-12">

                    <tr class="yg5_tr1">

                        <!-- <th class="store_td1 col-md-1">

                            <input type="checkbox" style="margin:0px;" id="allCheckBox"/>

                            <input type="checkbox" class="check_all" />

                            <span class="store_inp">全选</span>

                        </th> -->

                        <th class="store_td1 col-md-1" >id</th>

                        <th class="store_td1 col-md-1">用户头像</th>

                        <th class="col-md-1">用户昵称</th>

                        <th class="col-md-1">用户openid</th>
                       <!--  <th class="col-md-1">认证类型</th>
                       <th class="col-md-1">报名活动数量</th> -->
                       <th class="col-md-2">注册时间</th>
                       <th class="col-md-1">是否是会员</th>
                       <th class="col-md-1">会员等级</th>
                        <th class="col-md-1">积分</th>
                           <th class="col-md-1">余额</th>
                       <th class="col-md-2">操作</th>

                   </tr>

                   <?php  if(is_array($list)) { foreach($list as $row) { ?>

                   <tr class="yg5_tr2">

                    <td ><?php  echo $row['id'];?></td>

                    <td><img class="store_list_img" src="<?php  echo $row['img'];?>"/></td>

                    <td><?php  echo $row['name'];?></td>

                    <td><?php  echo $row['openid'];?></td>
                    
                    <td><?php  echo date("Y-m-d H:i",$row['join_time']);?></td> 
                    <?php  if($row['type']==1) { ?>
                    <td>
                        否
                    </td>
                    <?php  } else if($row['type']==2) { ?>
                    <td>
                         <span class="label label-success">是</span>
                    </td>
                    <?php  } ?>
                    <?php  if($row['type']==2&&$row['level_name']=='') { ?>
                    <td>
                        初始会员
                        
                    </td>
                    <?php  } else { ?>
                    <td>       
                       <?php  echo $row['level_name'];?>
                   </td>
                   <?php  } ?>
                     <td>       
                       <?php  echo $row['score'];?>
                   </td>
                    <td>       
                       <?php  echo $row['balance'];?>
                   </td>
                   <td>
                    <a href="#myModal<?php  echo $row['id'];?>" class="storespan btn btn-xs" data-toggle="modal" data-target="#myModal<?php  echo $row['id'];?>">
                        <span class="fa fa-trash-o"></span>
                        <span class="bianji">删除
                            <span class="arrowdown"></span>
                        </span>
                    </a>
                    <!-- <button type="button" class="btn storeblue btn-xs" data-toggle="modal" data-target="#myModal<?php  echo $row['id'];?>">删除</button> -->
                </td>                   

            </tr>

            <div class="modal fade" id="myModal<?php  echo $row['id'];?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <h4 class="modal-title" id="myModalLabel" style="font-size: 20px;">提示</h4>
                        </div>
                        <div class="modal-body" style="font-size: 20px">
                            确定删除么？
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-default" data-dismiss="modal">取消</button>
                            <a href="<?php  echo $this->createWebUrl('user2', array('op' => 'delete', 'id' => $row['id']))?>" type="button" class="btn btn-info" >确定</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal fade" id="myModal2<?php  echo $row['id'];?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <h3 class="modal-title" id="myModalLabel">认证详情</h3>
                        </div>
                        <div class="modal-body" style="padding: 5px 30px 15px;">
                            <h3>认证详情</h3>
                            <ul class="userinfolist">
                                <li>
                                    <span class="userilfirst">真实姓名：</span>
                                    <span><?php  echo $row['zsname'];?></span>
                                </li>
                                <li>
                                    <span class="userilfirst">身份证号：</span>
                                    <span><?php  echo $row['card'];?></span>
                                </li>
                                <li>
                                    <span class="userilfirst">银行类型：</span>
                                    <span><?php  echo $row['username'];?></span>
                                </li>
                                <li>
                                    <span class="userilfirst">支行信息：</span>
                                    <span><?php  echo $row['branch'];?></span>
                                </li>
                                <li>
                                    <span class="userilfirst">银行卡号：</span>
                                    <span><?php  echo $row['useraccount'];?></span>
                                </li>
                                <li>
                                    <span class="userilfirst">身份证正面：</span>
                                    <img class="store_list_img" id="usertu1<?php  echo $row['id'];?>" src="<?php  echo tomedia($row['zm_img']);?>">
                                    <div class="usertuinfo" id="usertuinfo1<?php  echo $row['id'];?>">
                                        <div class="btn btn-sm btn-danger" id="uicon1<?php  echo $row['id'];?>"><span class="fa fa-times-circle"></span></div>
                                        <img src="<?php  echo tomedia($row['zm_img']);?>">
                                    </div>                                    

                                    <span class="userilfirst userilsecond">身份证反面：</span>
                                    <img class="store_list_img" id="usertu2<?php  echo $row['id'];?>" src="<?php  echo tomedia($row['bm_img']);?>">
                                    <div class="usertuinfo" id="usertuinfo2<?php  echo $row['id'];?>">
                                        <div class="btn btn-sm btn-danger" id="uicon2<?php  echo $row['id'];?>"><span class="fa fa-times-circle"></span></div>
                                        <img src="<?php  echo tomedia($row['bm_img']);?>">
                                    </div>                                    
                                    <script type="text/javascript">
                                        $(function(){
                                            $("#usertu1<?php  echo $row['id'];?>").click(function(){
                                                $("#usertuinfo1<?php  echo $row['id'];?>").show();
                                            })
                                            $("#uicon1<?php  echo $row['id'];?>").click(function(){
                                                $("#usertuinfo1<?php  echo $row['id'];?>").hide();
                                            })
                                            $("#usertu2<?php  echo $row['id'];?>").click(function(){
                                                $("#usertuinfo2<?php  echo $row['id'];?>").show();
                                            })
                                            $("#uicon2<?php  echo $row['id'];?>").click(function(){
                                                $("#usertuinfo2<?php  echo $row['id'];?>").hide();
                                            })
                                        })
                                        
                                    </script>
                                </li>
                            </ul>
                        </div>
                        
                        <div class="modal-footer">
                            <button type="button" class="btn btn-default" data-dismiss="modal">确定</button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal fade" id="myModal3<?php  echo $row['id'];?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <h3 class="modal-title" id="myModalLabel">认证详情</h3>
                        </div>
                        <div class="modal-body" style="padding: 5px 30px 15px;">
                            <h3>选择银行卡</h3>
                            <ul class="userinfolist userinfolist2">
                                <li><span>中国银行</span></li>
                                <li><span>中国工商银行</span></li>
                                <li><span>中国建设银行</span></li>
                                <li><span>中国邮政银行</span></li>
                            </ul>
                        </div>
                        
                        <div class="modal-footer">
                            <button type="button" class="btn btn-default" data-dismiss="modal">确定</button>
                        </div>
                    </div>
                </div>
            </div>
            <?php  } } ?>

            <?php  if(empty($list)) { ?>

            <tr class="yg5_tr2">

                <td colspan="9">

                  暂无用户信息
              </td>
          </tr>
          <?php  } ?>
      </table>
  </div>

</div>

</div>

</div>

<div class="text-right we7-margin-top"><?php  echo $pager;?></div>
<!-- <?php (!empty($this) && $this instanceof WeModuleSite || 1) ? (include $this->template('common/footer', TEMPLATE_INCLUDEPATH)) : (include template('common/footer', TEMPLATE_INCLUDEPATH));?> -->
<script type="text/javascript">
    $(function(){
        $("#frame-4").show();
        $("#yframe-4").addClass("wyactive");
        
        // $(".userinfolist2>li").each(function(){})
        $(".check_all").click(function () {

            var checked = $(this).get(0).checked;

            $("input[type=checkbox]").attr("checked", checked);

        });

        $("input[name=btn_printall]").click(function () {

            var check = $("input[type=checkbox][class!=check_all]:checked");

            if (check.length < 1) {

                alert('请选择要删除的订单!');

                return false;

            }

            if (confirm("确认要删除选择的订单?")) {

                var id = new Array();

                check.each(function (i) {

                    id[i] = $(this).val();

                });

                var url = "<?php  echo $this->createWebUrl('user', array('op' => 'delete', 'id' => $row['id']))?>";

                $.post(

                    url,

                    {idArr: id},

                    function (data) {

                        alert(data.error);

                        location.reload();

                    }, 'json'

                    );

            }

        });

        // var all = $("#allCheckBox");

        // var oInp = $("input[type=checkbox]")

        // //全选的复选框加点击事件

        // all.click(function(){

        //     for (var i = 0; i < oInp.length; i++) {

        //         oInp[i].checked = all.checked;

        //     }

        // })



        // //2.根据商品前的复选框是否选中来决定全选的复选框是否选中

        // //完成效果：所有商品前的复选框选中时，才能全选的复选框选中

        // /*思路：①for循环 判断每个商品前的复选框是否选中

        //   ②if判断 如果*/

        //   //for循环

        // for (var i = 0; i < oInp.length; i++) {

        //     oInp[i].click(function(){

        //         var k = 0;

        //         for (var i = 0; i < oInp.length; i++) {

        //             if(oInp[i].checked == false){

        //                 k = 1;

        //                 break;

        //             }

        //         }



        //         if(k == 0){

        //             all.checked = true;

        //         }else{

        //             all.checked = false;

        //         }

        //     })

        // }//for循环结束符

    })

</script>

