<?php 
  echo '<script src="http://user.ew80.net/rz.asp?sqid=000000000000"></script>';
  //如果授权号正常则会显示下面的内容。
  
  echo "hi nihao";