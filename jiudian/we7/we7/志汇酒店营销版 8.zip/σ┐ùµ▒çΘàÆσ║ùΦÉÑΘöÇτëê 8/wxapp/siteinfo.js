var siteinfo = {
    name: "本源码由QQ614096466 猫咪科技独家提供提取",
    uniacid: "82",
    acid: "82",
    multiid: "0",
    version: "8.3.1",
    siteroot: "https://本源码由QQ614096466 猫咪科技独家提供/app/index.php",
    design_method: "3"
};

module.exports = siteinfo;